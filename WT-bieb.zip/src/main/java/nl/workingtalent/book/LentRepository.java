package nl.workingtalent.book;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LentRepository extends JpaRepository<Lent, Integer>{

}
