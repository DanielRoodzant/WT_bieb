package nl.workingtalent.book.dto;

public class SearchBookDto {

	private String zoekterm;
	

	public String getZoekterm() {

		return zoekterm;
	}
	
	public void setZoekterm(String zoekterm) {

		this.zoekterm=zoekterm;
	}


	

}
