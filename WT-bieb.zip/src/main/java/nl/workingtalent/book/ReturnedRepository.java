package nl.workingtalent.book;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReturnedRepository extends JpaRepository<Returned, Integer>{

}
